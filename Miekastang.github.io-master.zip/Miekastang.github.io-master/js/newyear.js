//Mieka Stang
//5/12/20
//(c) Public Access

//function get fortune with math.random

function getFortune (str){
var value = Math.floor(Math.random() * 72);;
  if (value == 0){
    return "You will have a forever partner.";
  }
  else if (value == 1){
    return "You will have lots of love in your family.";
  }
  else if (value == 2){
    return "You will get a rainbow snake.";
  }
  else if (value == 3){
    return "You will come to my house and play.";
  }
  else if (value == 4){
    return "You will go to Hawaii and play a lot.";
  }
  else if (value == 5){
    return "You will go to eat ice cream.";
  }
   else if (value == 6){
      return "You will go to In-N-Out.";
    }
    else if (value == 7){
      return "You will go on an adventure to an Amazon Forest.";
    }
    else if (value == 8){
      return "You will go to Dubai.";
    }
    else if (value == 9){
      return "You will go to Disney on Ice.";
    }
    else if (value == 10){
      return "You will go to Italy & eat pizza & go to the Leaning Tower of Pisa.";
    }
    else if (value == 11){
      return "You will go on an adventure on an airplane flight to Hong Kong.";
    }
    else if (value == 12){
      return "You will go to Spiderland.";
    }
    else if (value == 13){
      return "You will go to the top of Burj Khalifa (the tallest building in the world)!";
    }
    else if (value == 14){
      return "You will bounce on a silly trampoline.";
    }
    else if (value == 15){
      return "You will bounce in a bouncy castle.";
    }
    else if (value == 16){
      return "You will go to Legoland.";
    }
    else if (value == 17){
      return "You will go to the beach & see crabs & fish.";
    }
    else if (value == 18){
      return "You will have 100 cats.";
    }
    else if (value == 19){
      return "You will see your mom in Oakland.";
    }
    else if (value == 20){
      return "You will go flying from a trampoline into outer space.";
    }
    else if (value == 21){
      return "You will go to Disneyland and go on rides.";
    }
    else if (value == 22){
      return "You will see giant chickens!";
    }
    else if (value == 23){
      return "You will see 100 raindrops coming down from the sky.";
    }
    else if (value == 24){
      return "You will have a flying computer.";
    }
    else if (value == 25){
      return "You will go to the Statue of Unity (the world’s tallest statue).";
    }
    else if (value == 26){
      return "You will go to Tahoe and play and ski in the snow.";
    }
    else if (value == 27){
      return "You will dream about snow and ice.";
    }
    else if (value == 28){
      return "You will dream about turning into a fairy.";
    }
    else if (value == 29){
      return " You will play a magic harp.";
    }
    else if (value == 30){
      return "You will travel to the Pacific Ocean and sit on a boat.";
    }
    else if (value == 31){
      return "You will go to Hawaii and have breakfast and lunch and dinner at restaurants.";
    }
    else if (value == 32){
      return "You will swim in the water & jump & land in a tree.";
    }
    else if (value == 33){
      return "You will fly and land in a tree and play with a crow.";
    }
    else if (value == 34){
      return "You will swim in a lake and play football.";
    }
    else if (value == 35){
      return "You will ride a magic unicorn.";
    }
    else if (value == 36){
      return "You will go to London and ride a double-decker bus.";
    }
    else if (value == 37){
      return "You will see Glowfari.";
    }
    else if (value == 38){
      return "You will go to Mexico and have so much fun with your cousins.";
    }
    else if (value == 39){
      return "You will go to Maui and play in the sand.";
    }
    else if (value == 40){
      return "You will go to Japan & go to a toy store & buy some Japanese toys.";
    }
    else if (value == 41){
      return "You will go to Palm Springs and play a lot.";
    }
    else if (value == 42){
      return "You will go to a star up above with an alien.";
    }
    else if (value == 43){
      return "You will build an ice castle.";
    }
    else if (value == 44){
      return "You will go skiing in Park City.";
    }
    else if (value == 45){
      return "You will eat ice cream at the beach in Hawaii.";
    }
    else if (value == 46){
      return "You will go to a skyscraper every day.";
    }
    else if (value == 47){
      return "You will go to the Transamerica Tower every day.";
    }
    else if (value == 48){
      return "You will go to Trampolinium.";
    }
    else if (value == 49){
      return "You will see Fairyland.";
    }
    else if (value == 50){
      return "You will go to Jumpity Bumpity.";
    }
    else if (value == 51){
      return "You will go to Asia and swim in the Dead Sea.";
    }
    else if (value == 52){
      return "You will go to Antarctica and see seals and penguins.";
    }
    else if (value == 53){
      return "You will go to the Arctic Sea and see a polar bear.";
    }
    else if (value == 54){
      return "You will be a hero.";
    }
    else if (value == 55){
      return "You will go to Hawaii and do fun things.";
    }
    else if (value == 56){
      return "You will go to Australia and see a koala.";
    }
    else if (value == 57){
      return "You will have a dance party on Jupiter.";
    }
    else if (value == 58){
      return "You will go to Mexico and swim in the pools.";
    }
    else if (value == 59){
      return "You will go on an airplane to your cousin’s house.";
    }
    else if (value == 60){
      return "You will tell lots of jokes.";
    }
    else if (value == 61){
      return "You will travel around the sun. Don’t forget your sunglasses!";
    }
    else if (value == 62){
      return "You will go on a train ride to Oakland Zoo.";
    }
    else if (value == 63){
      return "You will count to 100.";
    }
    else if (value == 64){
      return "You will go to Highway 13.";
    }
    else if (value == 65){
      return "You will fly over a mountain.";
    }
    else if (value == 66){
      return "You will ski down a mountain.";
    }
    else if (value == 67){
      return "You will go to Monster Jam.";
    }
    else if (value == 68){
      return "You will learn to write fortunes.";
    }
    else if (value == 69){
      return "You will go to a special place and pick lots of flowers.";
    }
    else if (value == 70){
      return "You will go to Golf Land and play a LOT of arcade games!";
    }
    else if (value == 71){
      return "You will go to Chuck E. Cheese for your birthday.";
    }
    else {
      return "You will learn to speak mouse.";
    }
}

//On button run function
var button = document.getElementById("button");
  button.addEventListener("click",function (){
    var fortune = getFortune();
  button.addEventListener("click", console.log("working"));
//output
  var outputEl = document.getElementById ("output");
    outputEl.innerHTML = fortune
    outputEl.style.fontFamily = "Comic Sans MS,Arial,sans-serif"
    outputEl.style.color = " #dfa727";
  outputEl.style.backgroundImage = "url('banner.png')";
  outputEl.style.backgroundPosition = "center";
  outputEl.style.backgroundRepeat = "no-repeat";
  outputEl.style.backgroundSize = "cover";
});
